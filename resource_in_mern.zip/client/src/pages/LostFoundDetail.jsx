import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { lostFoundApi, claimApi, messageApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';

const LostFoundDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [claimForm, setClaimForm] = useState({ verificationDetails: '', preferredPickupTime: '' });
  const [claimError, setClaimError] = useState('');
  const [claimSuccess, setClaimSuccess] = useState('');
  const [claimLoading, setClaimLoading] = useState(false);
  const [msgContent, setMsgContent] = useState('');
  const [msgSent, setMsgSent] = useState(false);
  const [msgError, setMsgError] = useState('');

  useEffect(() => {
    lostFoundApi.getOne(id)
      .then(res => setItem(res.data.item))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Delete this report?')) return;
    try {
      await lostFoundApi.remove(id);
      navigate('/lost-found');
    } catch (err) {
      alert(err.message);
    }
  };

  const handleClaim = async (e) => {
    e.preventDefault();
    setClaimError('');
    setClaimLoading(true);
    try {
      await claimApi.create({ item: id, ...claimForm });
      setClaimSuccess('Your claim has been submitted! The reporter will review it.');
      setClaimForm({ verificationDetails: '', preferredPickupTime: '' });
    } catch (err) {
      setClaimError(err.message);
    } finally {
      setClaimLoading(false);
    }
  };

  const handleMessage = async (e) => {
    e.preventDefault();
    setMsgError('');
    try {
      await messageApi.send({ recipient: item.reporter._id, content: msgContent, relatedLostFound: id });
      setMsgSent(true);
      setMsgContent('');
    } catch (err) {
      setMsgError(err.message);
    }
  };

  const isOwner = user && item && user._id === item.reporter?._id;
  const isAdmin = user?.role === 'admin';

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (error) return <div className="error-page"><div className="alert alert-error">{error}</div><Link to="/lost-found">← Back</Link></div>;

  return (
    <div className="app-layout">
      <Header />
      <div className="main-container">
        <Sidebar />
        <main className="main-content">
          <div className="content-header">
            <h1 className="page-title">{item.title}</h1>
            {(isOwner || isAdmin) && (
              <div className="header-actions">
                <Link to={`/lost-found/${id}/edit`} className="btn btn-secondary">✏️ Edit</Link>
                <button onClick={handleDelete} className="btn btn-danger">🗑️ Delete</button>
              </div>
            )}
          </div>

          <div className="detail-card">
            <div className="detail-image">
              <img src={item.imageUrl || (item.reportType === 'found' ? '/loupe.png' : '/key.png')} alt={item.title} />
              <span className={`status-badge status-badge-lg ${item.reportType}`}>{item.reportType.toUpperCase()}</span>
            </div>
            <div className="detail-info">
              <div className="badges-row">
                <span className={`badge badge-status badge-${item.status}`}>{item.status}</span>
              </div>
              <p className="detail-desc">{item.description}</p>
              <p className="detail-meta">📍 <strong>Location:</strong> {item.location}</p>
              <p className="detail-meta">📅 <strong>Date:</strong> {new Date(item.incidentDate).toLocaleDateString()}</p>
              <p className="detail-meta">👤 <strong>Reported by:</strong> {item.reporter?.username || 'Unknown'}</p>
              <p className="detail-meta">🕒 <strong>Posted:</strong> {new Date(item.createdAt).toLocaleDateString()}</p>
            </div>
          </div>

          {/* Claim Form — only for found items, open status, authenticated non-owners */}
          {user && !isOwner && item.reportType === 'found' && item.status === 'open' && (
            <div className="claim-section">
              <h2>Claim This Item</h2>
              {claimSuccess && <div className="alert alert-success">{claimSuccess}</div>}
              {claimError && <div className="alert alert-error">{claimError}</div>}
              {!claimSuccess && (
                <form onSubmit={handleClaim} className="claim-form">
                  <div className="form-group">
                    <label className="form-label" htmlFor="verificationDetails">
                      Ownership Verification *
                      <small> (Private — only visible to the reporter)</small>
                    </label>
                    <textarea
                      id="verificationDetails"
                      className="form-input"
                      rows={4}
                      placeholder="Describe identifying details that prove this is yours…"
                      value={claimForm.verificationDetails}
                      onChange={e => setClaimForm(f => ({ ...f, verificationDetails: e.target.value }))}
                      required maxLength={500}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="pickupTime">Preferred Pickup Time</label>
                    <input
                      id="pickupTime"
                      className="form-input"
                      placeholder="e.g. Weekdays after 5pm"
                      value={claimForm.preferredPickupTime}
                      onChange={e => setClaimForm(f => ({ ...f, preferredPickupTime: e.target.value }))}
                      maxLength={200}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" disabled={claimLoading}>
                    {claimLoading ? 'Submitting…' : 'Submit Claim'}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Message reporter */}
          {user && !isOwner && (
            <div className="message-section">
              <h2>Contact Reporter</h2>
              {msgSent && <div className="alert alert-success">Message sent!</div>}
              {msgError && <div className="alert alert-error">{msgError}</div>}
              {!msgSent && (
                <form onSubmit={handleMessage} className="message-form">
                  <textarea className="form-input" rows={3} placeholder="Write a message…" value={msgContent} onChange={e => setMsgContent(e.target.value)} required maxLength={2000} />
                  <button type="submit" className="btn btn-secondary">Send Message</button>
                </form>
              )}
            </div>
          )}

          <Link to="/lost-found" className="back-link">← Back to Lost &amp; Found</Link>
        </main>
      </div>
    </div>
  );
};

export default LostFoundDetail;
