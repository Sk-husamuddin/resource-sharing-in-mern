import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { claimApi } from '../services/api';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';

const Claims = () => {
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionMsg, setActionMsg] = useState('');

  const fetchClaims = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await claimApi.getAll();
      setClaims(res.data.claims || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClaims();
  }, []);

  const handleWithdraw = async (id) => {
    if (!window.confirm('Are you sure you want to withdraw this claim?')) return;
    try {
      await claimApi.remove(id);
      setActionMsg('Claim successfully withdrawn.');
      setClaims((prev) => prev.filter((c) => c._id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="app-layout">
      <Header />
      <div className="main-container">
        <Sidebar />
        <main className="main-content">
          <div className="content-header">
            <h1 className="page-title">My Claims</h1>
            <Link to="/lost-found" className="report-btn">
              Browse Found Items
            </Link>
          </div>

          {actionMsg && <div className="alert alert-success">{actionMsg}</div>}
          {error && <div className="alert alert-error">{error}</div>}

          {loading && (
            <div className="loading-state">
              <div className="spinner" /> Loading claims…
            </div>
          )}

          {!loading && !error && claims.length === 0 && (
            <div className="empty-state">
              <span>📋</span>
              <p>You haven't submitted any claims yet.</p>
              <Link to="/lost-found" className="btn btn-primary" style={{ marginTop: '16px' }}>
                Browse Lost &amp; Found
              </Link>
            </div>
          )}

          {!loading && claims.length > 0 && (
            <div className="table-responsive">
              <table className="custom-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Status</th>
                    <th>Pickup Preference</th>
                    <th>Date Submitted</th>
                    <th>Reviewed By</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {claims.map((c) => (
                    <tr key={c._id}>
                      <td>
                        <strong>{c.item?.title || 'Unknown Item'}</strong>
                        {c.item && (
                          <div style={{ fontSize: '12px' }}>
                            <Link to={`/lost-found/${c.item._id}`} className="table-link">
                              View Item
                            </Link>
                          </div>
                        )}
                      </td>
                      <td>
                        <span className={`status-badge badge-${c.status}`}>{c.status}</span>
                      </td>
                      <td>{c.preferredPickupTime || 'Not specified'}</td>
                      <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                      <td>{c.reviewer?.username || 'Pending'}</td>
                      <td>
                        {c.status === 'pending' && (
                          <button
                            onClick={() => handleWithdraw(c._id)}
                            className="btn-sm btn-danger"
                          >
                            Withdraw
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Claims;
