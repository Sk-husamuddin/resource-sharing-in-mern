import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { lostFoundApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';

const ITEM_IMGS = { lost: '/key.png', found: '/loupe.png' };

const LostFound = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const fetchItems = async () => {
    setLoading(true);
    setError('');
    try {
      const params = { page };
      if (typeFilter) params.reportType = typeFilter;
      if (statusFilter) params.status = statusFilter;
      if (search) params.search = search;
      const res = await lostFoundApi.getAll(params);
      setItems(res.data.items);
      setPages(res.data.pages);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchItems(); }, [typeFilter, statusFilter, page]);

  const handleSearch = (e) => { e.preventDefault(); setPage(1); fetchItems(); };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this report?')) return;
    try {
      await lostFoundApi.remove(id);
      setItems(prev => prev.filter(i => i._id !== id));
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="app-layout">
      <Header />
      <div className="main-container">
        <Sidebar />
        <main className="main-content">
          <div className="content-header">
            <h1 className="page-title">Lost &amp; Found</h1>
            {user && <Link to="/lost-found/new" className="report-btn">+ Report Item</Link>}
          </div>

          <div className="search-filter-bar">
            <form onSubmit={handleSearch} className="search-box">
              <input className="search-input" placeholder="Search items…" value={search} onChange={e => setSearch(e.target.value)} />
              <button type="submit" className="search-btn">
                <img src="/loupe.png" alt="Search" className="search-icon" />
              </button>
            </form>
            <select className="filter-select" value={typeFilter} onChange={e => { setTypeFilter(e.target.value); setPage(1); }}>
              <option value="">All Types</option>
              <option value="lost">Lost</option>
              <option value="found">Found</option>
            </select>
            <select className="filter-select" value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}>
              <option value="">All Statuses</option>
              <option value="open">Open</option>
              <option value="claimed">Claimed</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
          </div>

          {loading && <div className="loading-state"><div className="spinner" /> Loading…</div>}
          {error && <div className="alert alert-error">{error}</div>}
          {!loading && !error && items.length === 0 && (
            <div className="empty-state"><span>🔍</span><p>No items found.</p></div>
          )}

          {!loading && (
            <div className="items-grid">
              {items.map(item => {
                const isOwner = user && user._id === item.reporter?._id;
                const isAdmin = user?.role === 'admin';
                return (
                  <div key={item._id} className={`item-card ${item.reportType}`}>
                    <span className={`status-badge ${item.reportType}`}>{item.reportType}</span>
                    <div className="item-image">
                      <img src={item.imageUrl || ITEM_IMGS[item.reportType]} alt={item.title} />
                    </div>
                    <div className="item-details">
                      <h3>{item.title}</h3>
                      <p className="item-description">{item.description.substring(0, 100)}{item.description.length > 100 ? '…' : ''}</p>
                      <div className="item-meta">
                        <span className="location">📍 {item.location}</span>
                        <span className="date">📅 {new Date(item.incidentDate).toLocaleDateString()}</span>
                      </div>
                      <div className="item-actions">
                        <Link to={`/lost-found/${item._id}`} className="contact-btn">
                          {item.reportType === 'found' ? 'Claim Item' : 'View Details'}
                        </Link>
                        {(isOwner || isAdmin) && (
                          <>
                            <Link to={`/lost-found/${item._id}/edit`} className="btn-sm btn-secondary">Edit</Link>
                            <button onClick={() => handleDelete(item._id)} className="btn-sm btn-danger">Delete</button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {pages > 1 && (
            <div className="pagination">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-secondary">← Prev</button>
              <span>Page {page} of {pages}</span>
              <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages} className="btn-sm btn-secondary">Next →</button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default LostFound;
