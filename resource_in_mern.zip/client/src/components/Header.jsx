import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

const Header = () => {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [loggingOut, setLoggingOut] = useState(false);

  const isWelcomePage = location.pathname === '/';

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await logout();
      navigate('/');
    } finally {
      setLoggingOut(false);
    }
  };

  return (
    <header className={`header ${isWelcomePage ? 'header-welcome' : ''}`}>
      <div className="logo-div">
        <Link to={user ? '/dashboard' : '/'} className="logo-link">
          <h2 className="logo-text">🔗 Resource Hub</h2>
        </Link>
      </div>
      <div className="right-section">
        {user ? (
          <div className="user-info">
            {isAdmin && (
              <Link to="/admin" className="admin-link">Admin</Link>
            )}
            <Link to="/profile" className="username-link">
              👤 {user.username}
            </Link>
            <button
              onClick={handleLogout}
              className="logout-btn"
              disabled={loggingOut}
            >
              {loggingOut ? 'Logging out…' : 'Logout'}
            </button>
          </div>
        ) : (
          <>
            <Link to="/login" className="get-cls">Sign In</Link>
            <Link to="/signup" className="button-cls">Join Now</Link>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;
